# -*- coding: utf-8 -*-
"""Import the entry point of AgentScope Studio."""
from ._app import init

__all__ = ["init"]
