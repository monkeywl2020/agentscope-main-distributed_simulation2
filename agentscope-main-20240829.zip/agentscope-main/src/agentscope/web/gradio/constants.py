# -*- coding: utf-8 -*-
""" Some constants used in the AS studio"""

_SPEAK = "**speak**"
